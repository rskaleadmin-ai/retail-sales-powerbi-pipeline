# Retail Sales Power BI Practice Dataset

These are synthetic, fictional records created for learning Power Query and Power BI. They do not represent real people or businesses.

## Files
- `orders.csv`: transaction/order-line records.
- `customers.csv`: customer dimension.
- `products.csv`: product dimension.
- `targets.csv`: monthly sales targets by region.

## Intended practice
The files deliberately include data-quality problems such as inconsistent formatting, missing values, type conversion errors, invalid values, duplicate keys, and unmatched IDs. Find and document the problems in Power Query rather than assuming every issue should be deleted.

## Important modeling note
`orders.csv` is intended to be line-level sales data. Use `OrderLineID` as the expected row-level key after resolving its duplicate. `OrderID` may repeat because an order can contain multiple product lines. `targets.csv` should have one row per Month and Region after cleanup. Review whether every target can be reliably matched to the sales date and region dimensions before using target KPIs.

All figures are synthetic and for practice only.
